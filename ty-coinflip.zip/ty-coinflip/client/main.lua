local Framework = nil

Citizen.CreateThread(function()
    if Config.Framework == "ESX" then
        while Framework == nil do
            TriggerEvent('esx:getSharedObject', function(obj) Framework = obj end)
            Citizen.Wait(0)
        end
    elseif Config.Framework == "QBCore" then
        Framework = exports['qb-core']:GetCoreObject()
    end
end)

RegisterNetEvent('jmj-coinflip:client:FlipCoin')
AddEventHandler('jmj-coinflip:client:FlipCoin', function()
    local playerPed = PlayerPedId()

    -- Play coin flip animation
    RequestAnimDict("anim@mp_player_intcelebrationmale@coin_roll_and_toss")
    while not HasAnimDictLoaded("anim@mp_player_intcelebrationmale@coin_roll_and_toss") do
        Citizen.Wait(100)
    end
    TaskPlayAnim(playerPed, "anim@mp_player_intcelebrationmale@coin_roll_and_toss", "coin_roll_and_toss", 8.0, -8.0, -1, 0, 0, false, false, false)

    -- Wait for animation to finish
    Citizen.Wait(GetAnimDuration("anim@mp_player_intcelebrationmale@coin_roll_and_toss", "coin_roll_and_toss") * 1000)

    -- Show result
    local result = math.random(2) == 1 and Config.Locale.heads or Config.Locale.tails
    if Config.Display3DTextEnabled then
        TriggerEvent('jmj-coinflip:client:Show3DText', playerPed, result)
    end
    if Config.NotifySelfEnabled then
        NotifyPlayer(string.format(Config.Locale.coin_flip, result))
    end
    if Config.NotifyNearbyEnabled then
        TriggerServerEvent('jmj-coinflip:server:NotifyNearby', GetEntityCoords(playerPed), result)
    end

    -- Add coin back to inventory
    TriggerServerEvent('jmj-coinflip:server:AddCoinBack')
end)

RegisterNetEvent('jmj-coinflip:client:Show3DText')
AddEventHandler('jmj-coinflip:client:Show3DText', function(playerPed, text)
    local displayTime = Config.DisplayTime

    Citizen.CreateThread(function()
        local endTime = GetGameTimer() + displayTime
        while GetGameTimer() < endTime do
            Citizen.Wait(0)
            local coords = GetEntityCoords(playerPed)
            DrawText3D(coords.x, coords.y, coords.z + 1.0, text)
        end
    end)
end)

function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
        local factor = (string.len(text)) / 370
        DrawRect(_x, _y + 0.0150, 0.015 + factor, 0.03, 0, 0, 0, 75)
    end
end

function NotifyPlayer(msg)
    if Config.Framework == "ESX" then
        ESX.ShowNotification(msg)
    elseif Config.Framework == "QBCore" then
        Framework.Functions.Notify(msg, "success")
    end
end
