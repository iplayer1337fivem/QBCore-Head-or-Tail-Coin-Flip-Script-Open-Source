local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('flipCoin:flip')
AddEventHandler('flipCoin:flip', function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local result = math.random(2) == 1 and _('head') or _('tail')
    
    -- Play coin flip animation
    playCoinFlipAnimation()
    
    -- Display the result above the player's head after the animation
    Citizen.Wait(2000) -- wait for the animation to complete
    
    if Config.Display3DTextEnabled then
        Display3DText(result, Config.DisplayTime)
    end
    
    -- Notify the player
    if Config.NotifySelfEnabled then
        QBCore.Functions.Notify(_("flip_coin", result))
    end
    
    -- Notify nearby players, but not the player who flipped the coin
    if Config.NotifyNearbyEnabled then
        TriggerServerEvent('flipCoin:notifyNearby', result, playerCoords.x, playerCoords.y, playerCoords.z, PlayerPedId())
    end
    
    -- Notify the server to reset the item
    TriggerServerEvent('flipCoin:resetItem')
end)

function Display3DText(text, displayTime)
    local playerPed = PlayerPedId()
    local endTime = GetGameTimer() + displayTime

    Citizen.CreateThread(function()
        while GetGameTimer() < endTime do
            local playerCoords = GetEntityCoords(playerPed)
            local onScreen, _x, _y = World3dToScreen2d(playerCoords.x, playerCoords.y, playerCoords.z + 1.0)
            local scale = 0.35

            if onScreen then
                SetTextScale(scale, scale)
                SetTextFont(4)
                SetTextProportional(1)
                SetTextEntry("STRING")
                SetTextCentre(1)
                AddTextComponentString(text)
                DrawText(_x, _y)
                local factor = (string.len(text)) / 370
                DrawRect(_x, _y + 0.0150, 0.015 + factor, 0.03, 0, 0, 0, 75)
            end
            Citizen.Wait(0)
        end
    end)
end

function playCoinFlipAnimation()
    local playerPed = PlayerPedId()
    local animDict = "anim@mp_player_intcelebrationmale@coin_roll_and_toss"
    local animName = "coin_roll_and_toss"

    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do
        Citizen.Wait(100)
    end

    TaskPlayAnim(playerPed, animDict, animName, 8.0, -8.0, 2000, 49, 0, false, false, false)
    RemoveAnimDict(animDict)
end
