Config = {}

Config.ItemName = "coin"
Config.DisplayTime = 5000  -- Duration in milliseconds for how long the text is displayed above the player's head
Config.NotifyRange = 5.0 -- Range in meters for notifications to other players

-- Notification settings
Config.NotifyNearbyEnabled = true  -- Enable notifications for nearby players
Config.NotifySelfEnabled = false    -- Enable notifications for the player who performed the action

-- 3D Text settings
Config.Display3DTextEnabled = true  -- Enable or disable 3D text display

-- Translation key: value pairs
Config.Locale = {
    ['flip_coin'] = "You have flipped %s!",
    ['head'] = "Heads",
    ['tail'] = "Tails",
    ['coin_flipped'] = "It landed on %s!"
}
