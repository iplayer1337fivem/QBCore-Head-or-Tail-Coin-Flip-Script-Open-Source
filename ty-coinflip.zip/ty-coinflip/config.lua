Config = {}

-- ONLY QBCore
-- Framework settings: "ESX" or "QBCore"    
Config.Framework = "QBCore" -- ESX IS NOT WORKING NOW | WORK IN PROGRESS

-- Item name
Config.ItemName = "coin"

-- Display time for the 3D text (in milliseconds)
Config.DisplayTime = 5000

-- Notification range (in meters)
Config.NotifyRange = 5

-- Enable/Disable nearby notification
Config.NotifyNearbyEnabled = true

-- Enable/Disable self notification
Config.NotifySelfEnabled = true

-- Enable/Disable 3D text display
Config.Display3DTextEnabled = true
-- Localization
Config.Locale = {
    heads = "Heads",
    tails = "Tails",
    coin_flip = "You flipped a coin and got %s",
    notify_nearby = "A coin was flipped and landed on %s"
}
