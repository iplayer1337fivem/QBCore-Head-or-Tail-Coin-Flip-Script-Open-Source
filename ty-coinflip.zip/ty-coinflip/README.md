Thank you for downloading my coin flip script, feel free to edit anything you like make sure you have added the item “coin” to qb-core/shared/items.lua



['coin']                      = { ['name'] = 'coin',                          ['label'] = 'Coin',                    ['weight'] = 1,        ['type'] = 'item',      ['image'] = 'coin.png',          ['unique'] = true,                     ['useable'] = true,        ['shouldClose'] =       true,             ['combinable'] = nil,              ['description'] = 'Head or Tail, find it out!'},

