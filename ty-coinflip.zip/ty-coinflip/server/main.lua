local Framework = nil

Citizen.CreateThread(function()
    if Config.Framework == "ESX" then
        TriggerEvent('esx:getSharedObject', function(obj) Framework = obj end)
    elseif Config.Framework == "QBCore" then
        Framework = exports['qb-core']:GetCoreObject()
    else
        print("^1ERROR: Invalid framework selected in config.lua. Please choose either 'ESX' or 'QBCore'.^0")
        return
    end

    -- Wait for framework to be ready
    while Framework == nil do
        Citizen.Wait(0)
    end

    if Config.Framework == "ESX" then
        Framework.RegisterUsableItem(Config.ItemName, function(source)
            local xPlayer = Framework.GetPlayerFromId(source)
            xPlayer.removeInventoryItem(Config.ItemName, 1)
            TriggerClientEvent('ty-coinflip:client:FlipCoin', source)
        end)
    elseif Config.Framework == "QBCore" then
        Framework.Functions.CreateUseableItem(Config.ItemName, function(source)
            local Player = Framework.Functions.GetPlayer(source)
            Player.Functions.RemoveItem(Config.ItemName, 1)
            TriggerClientEvent('ty-coinflip:client:FlipCoin', source)
        end)
    end
end)

RegisterNetEvent('ty-coinflip:server:NotifyNearby')
AddEventHandler('ty-coinflip:server:NotifyNearby', function(coords, result)
    local players = nil
    if Config.Framework == "ESX" then
        players = Framework.GetPlayers()
    elseif Config.Framework == "QBCore" then
        players = Framework.Functions.GetPlayers()
    end
    
    for _, playerId in ipairs(players) do
        local xPlayer = nil
        if Config.Framework == "ESX" then
            xPlayer = Framework.GetPlayerFromId(playerId)
        elseif Config.Framework == "QBCore" then
            xPlayer = Framework.Functions.GetPlayer(playerId)
        end

        if xPlayer and #(coords - GetEntityCoords(GetPlayerPed(playerId))) < Config.NotifyRange and playerId ~= source then
            TriggerClientEvent('Framework:Notify', playerId, string.format(Config.Locale.notify_nearby, result), "success")
        end
    end
end)

RegisterNetEvent('ty-coinflip:server:AddCoinBack')
AddEventHandler('ty-coinflip:server:AddCoinBack', function()
    local xPlayer = nil
    if Config.Framework == "ESX" then
        xPlayer = Framework.GetPlayerFromId(source)
        xPlayer.addInventoryItem(Config.ItemName, 1)
    elseif Config.Framework == "QBCore" then
        local Player = Framework.Functions.GetPlayer(source)
        Player.Functions.AddItem(Config.ItemName, 1)
    end
end)
