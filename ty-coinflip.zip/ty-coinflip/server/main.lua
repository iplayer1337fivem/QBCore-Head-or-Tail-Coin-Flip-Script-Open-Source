local QBCore = exports['qb-core']:GetCoreObject()

-- Register the item usage
QBCore.Functions.CreateUseableItem(Config.ItemName, function(source, item)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        -- Remove the item from the player's inventory
        Player.Functions.RemoveItem(Config.ItemName, 1)
        
        -- Trigger the flipCoin event on the client
        TriggerClientEvent("flipCoin:flip", source)
    end
end)

RegisterNetEvent('flipCoin:resetItem')
AddEventHandler('flipCoin:resetItem', function()
    local Player = QBCore.Functions.GetPlayer(source)
    if Player then
        -- Add the item back to the player's inventory
        Player.Functions.AddItem(Config.ItemName, 1)
    end
end)

RegisterNetEvent('flipCoin:notifyNearby')
AddEventHandler('flipCoin:notifyNearby', function(result, x, y, z, sourcePedId)
    if not Config.NotifyNearbyEnabled then return end -- Check if nearby notifications are enabled

    -- Get all players and send a notification to those within the range, excluding the player who flipped the coin
    local players = GetPlayers()
    for _, playerId in ipairs(players) do
        if playerId ~= sourcePedId then
            local playerPed = GetPlayerPed(playerId)
            local playerCoords = GetEntityCoords(playerPed)
            local distance = #(vector3(x, y, z) - playerCoords)
            
            if distance <= Config.NotifyRange then
                local message = string.format(Config.Locale['coin_flipped'], result)
                TriggerClientEvent('QBCore:Notify', playerId, message)
            end
        end
    end
end)
