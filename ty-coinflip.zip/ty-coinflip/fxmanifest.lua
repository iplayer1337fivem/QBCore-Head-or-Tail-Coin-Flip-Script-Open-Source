fx_version 'cerulean'
game 'gta5'

description 'Coin Flip Script for FiveM (ESX & QBCore)'
author 'Treety'

shared_script 'config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'
